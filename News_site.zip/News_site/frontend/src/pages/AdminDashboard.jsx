import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchNews } from "../store/newsSlice";

const AdminDashboard = () => {
  const dispatch = useDispatch();
  const { articles } = useSelector((state) => state.news);

  return (
    <div>
      <h1>Admin Dashboard</h1>
      <button onClick={() => dispatch(fetchNews())}>Fetch News</button>
      {articles.map((news) => (
        <div key={news.id}>
          <h3>{news.title}</h3>
          <p>{news.content}</p>
        </div>
      ))}
    </div>
  );
};

export default AdminDashboard;
