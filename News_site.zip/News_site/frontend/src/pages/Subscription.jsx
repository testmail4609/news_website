import React from "react";

const Subscription = () => {
  return (
    <div>
      <h1>Subscription Plans</h1>
      <p>Choose a plan to get premium access to news.</p>
    </div>
  );
};

export default Subscription;
