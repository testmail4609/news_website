import axios from 'axios';

export const analyzeSentiment = async (text) => {
  try {
    const response = await axios.post(
      'https://api.openai.com/v1/completions',
      { prompt: `Analyze sentiment of: "${text}"`, model: 'gpt-4' },
      { headers: { Authorization: `Bearer ${process.env.OPENAI_API_KEY}` } }
    );
    return response.data.choices[0].text.trim();
  } catch (error) {
    return 'Neutral';
  }
};

export const getTrendingTopics = async () => {
  try {
    const response = await axios.post(
      'https://api.openai.com/v1/completions',
      { prompt: 'Get top 5 trending news topics.', model: 'gpt-4' },
      { headers: { Authorization: `Bearer ${process.env.OPENAI_API_KEY}` } }
    );
    return response.data.choices[0].text.split('\n');
  } catch (error) {
    return [];
  }
};
