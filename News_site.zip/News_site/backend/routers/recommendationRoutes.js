import express from "express";
import { getRecommendedNews } from "../controllers/recommendationController.js";
import authMiddleware from "../middleware/authMiddleware.js";

const router = express.Router();

router.get("/recommendations", authMiddleware, getRecommendedNews);

export default router;
