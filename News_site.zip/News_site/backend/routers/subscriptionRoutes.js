import express from "express";
import { upgradeSubscription } from "../controllers/subscriptionController.js";
import authMiddleware from "../middleware/authMiddleware.js";

const router = express.Router();

router.post("/upgrade", authMiddleware, upgradeSubscription);

export default router;
