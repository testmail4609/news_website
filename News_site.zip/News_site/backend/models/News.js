import mongoose from "mongoose";

const newsSchema = new mongoose.Schema(
  {
    title: {
      en: { type: String, required: true },
      es: { type: String },
      fr: { type: String },
    },
    content: {
      en: { type: String, required: true },
      es: { type: String },
      fr: { type: String },
    },
    imageUrl: { type: String },
    category: { type: String, required: true },
    publishedAt: { type: Date, default: Date.now },
  },
  { timestamps: true }
);

const News = mongoose.model("News", newsSchema);
export default News;
