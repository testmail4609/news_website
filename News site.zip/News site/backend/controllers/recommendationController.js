import News from "../models/News.js";
import User from "../models/User.js";

export const getRecommendedNews = async (req, res) => {
  try {
    const user = await User.findById(req.user.id);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    const userInterest = user.interests || ["general"]; // Default to general news
    const recommendedNews = await News.find({ category: { $in: userInterest } }).limit(5);

    res.json(recommendedNews);
  } catch (error) {
    res.status(500).json({ message: "Failed to fetch recommendations", error: error.message });
  }
};
