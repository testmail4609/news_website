import User from "../models/User.js";

export const upgradeSubscription = async (req, res) => {
  try {
    const user = await User.findById(req.user.id);
    if (!user) return res.status(404).json({ message: "User not found" });

    user.isSubscribed = true;
    await user.save();

    res.json({ message: "Subscription upgraded successfully" });
  } catch (error) {
    res.status(500).json({ message: "Failed to upgrade subscription", error: error.message });
  }
};

export const checkSubscription = async (req, res, next) => {
  const user = await User.findById(req.user.id);
  if (!user || !user.isSubscribed) {
    return res.status(403).json({ message: "Premium content access denied" });
  }
  next();
};
