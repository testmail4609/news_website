import { sendPushNotification } from "../utils/pushNotifications.js";

export const sendNewsUpdate = async (req, res) => {
  try {
    const { title, body, tokens } = req.body;

    if (!tokens || tokens.length === 0) {
      return res.status(400).json({ message: "No tokens provided" });
    }

    await sendPushNotification(title, body, tokens);
    res.json({ message: "Notification sent successfully" });
  } catch (error) {
    res.status(500).json({ message: "Failed to send notification", error: error.message });
  }
};
