export const getPremiumNews = async (req, res) => {
  try {
    const premiumNews = await News.find({ category: "Premium" });
    res.json(premiumNews);
  } catch (error) {
    res.status(500).json({ message: "Failed to fetch premium news", error: error.message });
  }
};
