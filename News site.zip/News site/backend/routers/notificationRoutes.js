import express from "express";
import { sendNewsUpdate } from "../controllers/notificationController.js";

const router = express.Router();

router.post("/send", sendNewsUpdate);

export default router;
