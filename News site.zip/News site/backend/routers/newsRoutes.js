import { getPremiumNews } from "../controllers/newsController.js";
import { checkSubscription } from "../controllers/subscriptionController.js";

router.get("/premium", authMiddleware, checkSubscription, getPremiumNews);
