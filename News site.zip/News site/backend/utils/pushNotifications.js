import admin from "firebase-admin";
import serviceAccount from "../config/firebaseServiceAccount.json" assert { type: "json" };

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
});

export const sendPushNotification = async (title, body, tokens) => {
  const message = {
    notification: { title, body },
    tokens,
  };

  try {
    await admin.messaging().sendMulticast(message);
    console.log("Push notification sent successfully.");
  } catch (error) {
    console.error("Failed to send push notification:", error);
  }
};
