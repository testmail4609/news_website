import React from "react";
import { Link } from "react-router-dom";
import LanguageSwitcher from "./LanguageSwitcher";

const Navbar = () => {
  return (
    <nav className="bg-gray-900 text-white p-4 flex justify-between items-center">
      <Link to="/" className="text-2xl font-bold">
        Dynamic News
      </Link>
      <div className="flex space-x-4">
        <Link to="/" className="hover:underline">Home</Link>
        <Link to="/subscription" className="hover:underline">Subscription</Link>
        <Link to="/login" className="hover:underline">Login</Link>
        <LanguageSwitcher />
      </div>
    </nav>
  );
};

export default Navbar;
