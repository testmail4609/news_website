import { useEffect } from "react";
import { getMessaging, onMessage } from "firebase/messaging";
import app from "../firebaseConfig";

const PushNotifications = () => {
  useEffect(() => {
    const messaging = getMessaging(app);
    onMessage(messaging, (payload) => {
      alert(`New Notification: ${payload.notification.title}`);
    });
  }, []);

  return <></>;
};

export default PushNotifications;
