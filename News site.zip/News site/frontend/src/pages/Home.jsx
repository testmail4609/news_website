import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchNews } from "../store/newsSlice";

const Home = () => {
  const dispatch = useDispatch();
  const { articles, status } = useSelector((state) => state.news);

  useEffect(() => {
    dispatch(fetchNews());
  }, [dispatch]);

  return (
    <div>
      <h1>News Portal</h1>
      {status === "loading" ? <p>Loading...</p> : 
        articles.map((news) => <p key={news.id}>{news.title}</p>)}
    </div>
  );
};

export default Home;
